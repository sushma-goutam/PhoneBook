from django.contrib import admin
from contactsapp.models import Contact

admin.site.register(Contact)
