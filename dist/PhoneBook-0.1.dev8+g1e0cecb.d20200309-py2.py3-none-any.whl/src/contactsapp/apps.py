from django.apps import AppConfig


class ContactsappConfig(AppConfig):
    name = 'contactsapp'
